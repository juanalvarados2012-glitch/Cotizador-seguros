# 🦅 Auto-Cotizador · Seguros Cóndor

App web para automatizar las cotizaciones de **Ramos Generales**. Sube la plantilla Excel del broker y la app:

- ⚡ Llena al instante las coberturas que ya conoce (sin gastar llamadas a IA)
- 🧠 Aprende: cada respuesta que corriges queda guardada para la próxima vez
- 🤖 Usa IA (Claude) solo para coberturas nuevas/sin precedente
- 📄 Te devuelve el **mismo Excel del broker respondido** + una hoja resumen

## Cómo funciona

1. Subes el archivo del broker (`.xlsx`, `.xls`, `.xlsm`)
2. La app detecta las hojas de coberturas y la columna donde va tu respuesta
3. Match híbrido por cada ítem: `Exacta` → `Similar` → `Pendiente`
4. Botón **Completar con IA** resuelve solo los pendientes
5. Revisas/editas (todo lo editado se aprende)
6. Exportas el archivo respondido

## Instalación

```bash
npm install
cp .env.example .env   # pon tu VITE_ANTHROPIC_API_KEY
npm run dev
```

Abre http://localhost:5173

## Build de producción

```bash
npm run build
npm run preview
```

## ⚠️ Nota de seguridad (API key)

La versión actual llama a la API de Anthropic directamente desde el navegador usando una key en `.env`.
**Para producción**, mueve esa llamada a un backend/proxy (Vercel Function, Cloudflare Worker, etc.)
para no exponer la clave. La función a mover está en `src/App.jsx → callClaude()`.

## Memoria

Las respuestas aprendidas se guardan en `localStorage` del navegador (clave `cotizador_condor_kb_v1`).
Para una versión multi-usuario o que sincronice entre equipos, conviene moverla a una base de datos.

## Stack

React 18 · Vite · SheetJS (xlsx) · Anthropic Claude API
